/* tslint:disable */
require("./JarbisWebPart.module.css");
const styles = {
  jarbis: 'jarbis_e238a861',
  logo: 'logo_e238a861',
  name: 'name_e238a861',
  powers: 'powers_e238a861'
};

export default styles;
/* tslint:enable */