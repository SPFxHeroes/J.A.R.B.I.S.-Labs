declare const styles: {
    jarbis: string;
    logo: string;
    name: string;
    powers: string;
};
export default styles;
//# sourceMappingURL=JarbisWebPart.module.scss.d.ts.map