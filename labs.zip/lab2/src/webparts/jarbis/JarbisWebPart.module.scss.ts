/* tslint:disable */
require("./JarbisWebPart.module.css");
const styles = {
  jarbis: 'jarbis_18cb6533',
  teams: 'teams_18cb6533',
  welcome: 'welcome_18cb6533',
  welcomeImage: 'welcomeImage_18cb6533',
  links: 'links_18cb6533'
};

export default styles;
/* tslint:enable */