declare const styles: {
    jarbis: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=JarbisWebPart.module.scss.d.ts.map